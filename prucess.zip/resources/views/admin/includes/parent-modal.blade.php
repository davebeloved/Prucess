<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Admin user actions</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>  
            <div class="modal-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-3">
                            <button class="btn btn-primary" data-bs-target="#edit" data-bs-toggle="modal" data-bs-dismiss="exampleModal">Edit</button>
                        </div>
                        <div class="col-3">
                            <button class="btn btn-primary" data-bs-target="#delete" data-bs-toggle="modal" data-bs-dismiss="exampleModal">Delete</button>
                        </div>
                        <div class="col-3">
                            <button class="btn btn-primary" data-bs-target="#message" data-bs-toggle="modal" data-bs-dismiss="exampleModal">Message</button>
                        </div>
                        <div class="col-3">
                            <button class="btn btn-primary" data-bs-target="#delete" data-bs-toggle="modal" data-bs-dismiss="exampleModal">Delete</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>